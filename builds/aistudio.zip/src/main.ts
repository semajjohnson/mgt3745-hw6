/**
 * Trip Moments - F2 Feature: Create a trip and invite members
 * Pure TypeScript/JavaScript with no framework and no external dependencies.
 * Follows strict style tokens and refusals.
 */

interface User {
  id: string;
  name: string;
  email: string;
  badge: string;
}

interface TripMember {
  userId: string;
  name: string;
  email: string;
  role: 'creator' | 'member';
  joinedAt: string;
}

interface TripMoment {
  id: string;
  authorName: string;
  text: string;
  place: string;
  timestamp: string;
}

interface Trip {
  id: string;
  name: string;
  destinationNote: string;
  creatorId: string;
  creatorName: string;
  inviteToken: string;
  createdAt: string;
  members: TripMember[];
  moments: TripMoment[];
}

interface FeedbackMessage {
  type: 'success' | 'error' | 'confirmation';
  title: string;
  detail: string;
}

// Preset User Profiles (Profile 1: Casual traveler, working professional)
const PRESET_USERS: User[] = [
  {
    id: 'user-marcus',
    name: 'Marcus Vance',
    email: 'marcus.vance@workmail.com',
    badge: 'Creator & Casual Traveler (Profile 1)'
  },
  {
    id: 'user-elena',
    name: 'Elena Rostova',
    email: 'elena.rostova@friend.org',
    badge: 'Friend on trip'
  },
  {
    id: 'user-samira',
    name: 'Samira Chen',
    email: 'samira.chen@home.net',
    badge: 'Friend back at home'
  },
  {
    id: 'user-stranger',
    name: 'Uninvited Visitor',
    email: 'visitor@unknown.org',
    badge: 'No invite credentials'
  }
];

const STORAGE_KEY = 'trip_moments_app_v1';

// Application State
class TripStore {
  currentUser: User = PRESET_USERS[0];
  trips: Trip[] = [];
  selectedTripId: string | null = null;
  activeTab: 'my-trips' | 'trip-detail' | 'create-trip' | 'join-trip' = 'trip-detail';
  feedback: FeedbackMessage | null = null;
  refusalState: { isRefused: boolean; attemptedLink: string } = { isRefused: false, attemptedLink: '' };

  constructor() {
    this.loadState();
  }

  loadState() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        this.trips = parsed.trips || [];
        const savedUserId = parsed.currentUserId;
        const foundUser = PRESET_USERS.find(u => u.id === savedUserId);
        if (foundUser) this.currentUser = foundUser;
        this.selectedTripId = parsed.selectedTripId || (this.trips[0] ? this.trips[0].id : null);
      } else {
        this.seedInitialData();
      }
    } catch {
      this.seedInitialData();
    }

    if (this.trips.length > 0 && !this.selectedTripId) {
      this.selectedTripId = this.trips[0].id;
    }
  }

  saveState() {
    const payload = {
      trips: this.trips,
      currentUserId: this.currentUser.id,
      selectedTripId: this.selectedTripId
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch {
      // Storage unavailable or quota exceeded
    }
  }

  seedInitialData() {
    const marcus = PRESET_USERS[0];
    const initialTrip: Trip = {
      id: 'trip-lisbon-2026',
      name: 'Weekend in Lisbon',
      destinationNote: 'Alfama & Belém · 4-day casual getaway',
      creatorId: marcus.id,
      creatorName: marcus.name,
      inviteToken: 'lisbon-casual-moments-token',
      createdAt: '2026-10-18T10:00:00Z',
      members: [
        {
          userId: marcus.id,
          name: marcus.name,
          email: marcus.email,
          role: 'creator',
          joinedAt: '2026-10-18T10:00:00Z'
        }
      ],
      moments: [
        {
          id: 'moment-1',
          authorName: 'Marcus Vance',
          text: 'Pastéis de Belém: warm custard tarts right out of the oven. Zero wait at 9am! Sending to the group.',
          place: 'Pastéis de Belém, Lisbon',
          timestamp: 'Oct 19, 9:20 AM'
        },
        {
          id: 'moment-2',
          authorName: 'Marcus Vance',
          text: 'Found a tiny underground fado tavern hidden in the cobblestones behind Miradouro de Santa Luzia.',
          place: 'Alfama Alleyway, Lisbon',
          timestamp: 'Oct 19, 8:45 PM'
        }
      ]
    };
    this.trips = [initialTrip];
    this.selectedTripId = initialTrip.id;
    this.saveState();
  }

  resetAll() {
    localStorage.removeItem(STORAGE_KEY);
    this.currentUser = PRESET_USERS[0];
    this.seedInitialData();
    this.activeTab = 'trip-detail';
    this.refusalState = { isRefused: false, attemptedLink: '' };
    this.feedback = {
      type: 'confirmation',
      title: 'Confirmation: Demo state restored',
      detail: 'Reset to initial state with Marcus Vance as creator of Weekend in Lisbon.'
    };
    this.saveState();
  }

  createTrip(name: string, destinationNote: string): Trip {
    const id = 'trip-' + Date.now();
    // Unique reusable invite token for this trip (F2-3)
    const sanitizedName = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const randomSuffix = Math.random().toString(36).substring(2, 8);
    const inviteToken = `${sanitizedName || 'trip'}-${randomSuffix}`;

    const newTrip: Trip = {
      id,
      name: name.trim(),
      destinationNote: destinationNote.trim() || 'Casual trip moments',
      creatorId: this.currentUser.id, // F2-1: signed-in person is creator
      creatorName: this.currentUser.name,
      inviteToken, // F2-3: Exactly one reusable invite token
      createdAt: new Date().toISOString(),
      members: [
        {
          userId: this.currentUser.id,
          name: this.currentUser.name,
          email: this.currentUser.email,
          role: 'creator',
          joinedAt: new Date().toISOString()
        }
      ],
      moments: []
    };

    this.trips.unshift(newTrip);
    this.selectedTripId = newTrip.id;
    this.activeTab = 'trip-detail';
    this.refusalState = { isRefused: false, attemptedLink: '' };
    this.saveState();
    return newTrip;
  }

  getInviteUrl(trip: Trip): string {
    const origin = window.location.origin;
    const pathname = window.location.pathname;
    return `${origin}${pathname}?invite=${trip.inviteToken}`;
  }

  joinTripWithToken(rawTokenOrUrl: string): boolean {
    const trimmed = rawTokenOrUrl.trim();
    if (!trimmed) {
      this.refusalState = { isRefused: true, attemptedLink: '(empty link)' };
      this.feedback = {
        type: 'error',
        title: 'Error: Access refused. Missing invite link',
        detail: 'An invite link is required to join a trip. No trip details can be shown.'
      };
      return false;
    }

    // Extract token if user pasted full URL
    let token = trimmed;
    try {
      if (trimmed.includes('?invite=')) {
        const url = new URL(trimmed, window.location.origin);
        token = url.searchParams.get('invite') || trimmed;
      }
    } catch {
      token = trimmed;
    }

    // Search for trip with this reusable invite token (F2-2 & F2-3)
    const matchingTrip = this.trips.find(t => t.inviteToken === token);

    if (!matchingTrip) {
      // F2-2: Refuse and show NO trip details
      this.refusalState = { isRefused: true, attemptedLink: trimmed };
      this.feedback = {
        type: 'error',
        title: 'Error: Access refused. Invalid invite link',
        detail: `The invite link "${trimmed}" is invalid, incomplete, or expired. Refusing access and showing no trip details.`
      };
      this.activeTab = 'join-trip';
      return false;
    }

    // Valid invite link verified!
    this.refusalState = { isRefused: false, attemptedLink: '' };
    this.selectedTripId = matchingTrip.id;

    // Check if current user is already a member
    const existingMember = matchingTrip.members.find(m => m.userId === this.currentUser.id);
    if (existingMember) {
      this.feedback = {
        type: 'confirmation',
        title: 'Confirmation: Already a member',
        detail: `You are already registered as ${existingMember.role === 'creator' ? 'the creator' : 'a member'} of "${matchingTrip.name}". Showing trip details.`
      };
    } else {
      // Add current user as a new member
      matchingTrip.members.push({
        userId: this.currentUser.id,
        name: this.currentUser.name,
        email: this.currentUser.email,
        role: 'member',
        joinedAt: new Date().toISOString()
      });
      this.feedback = {
        type: 'success',
        title: 'Success: Valid invite link verified',
        detail: `You have successfully joined "${matchingTrip.name}" as an invited member using the reusable invite link.`
      };
    }

    this.activeTab = 'trip-detail';
    this.saveState();
    return true;
  }

  removeMember(tripId: string, memberUserId: string) {
    const trip = this.trips.find(t => t.id === tripId);
    if (!trip) return;

    const memberToRemove = trip.members.find(m => m.userId === memberUserId);
    if (!memberToRemove) return;

    if (memberToRemove.role === 'creator') {
      this.feedback = {
        type: 'error',
        title: 'Error: Cannot remove trip creator',
        detail: 'The creator cannot be removed from the trip. A trip must retain its creator.'
      };
      return;
    }

    trip.members = trip.members.filter(m => m.userId !== memberUserId);
    this.feedback = {
      type: 'confirmation',
      title: 'Confirmation: Member removed',
      detail: `Successfully removed ${memberToRemove.name} from "${trip.name}".`
    };
    this.saveState();
  }

  deleteTrip(tripId: string) {
    const trip = this.trips.find(t => t.id === tripId);
    const tripName = trip ? trip.name : 'Trip';
    this.trips = this.trips.filter(t => t.id !== tripId);
    if (this.selectedTripId === tripId) {
      this.selectedTripId = this.trips[0] ? this.trips[0].id : null;
    }
    this.activeTab = this.trips.length > 0 ? 'trip-detail' : 'create-trip';
    this.feedback = {
      type: 'confirmation',
      title: 'Confirmation: Trip deleted',
      detail: `The trip "${tripName}" and all associated data were deleted permanently.`
    };
    this.saveState();
  }

  addMoment(tripId: string, text: string, place: string) {
    const trip = this.trips.find(t => t.id === tripId);
    if (!trip) return;

    const newMoment: TripMoment = {
      id: 'moment-' + Date.now(),
      authorName: this.currentUser.name,
      text: text.trim(),
      place: place.trim() || 'On the road',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' today'
    };

    trip.moments.unshift(newMoment);
    this.feedback = {
      type: 'success',
      title: 'Success: Moment shared to trip',
      detail: `Your moment was posted directly to "${trip.name}". Friends on the trip and at home can see it immediately.`
    };
    this.saveState();
  }

  deleteMoment(tripId: string, momentId: string) {
    const trip = this.trips.find(t => t.id === tripId);
    if (!trip) return;
    trip.moments = trip.moments.filter(m => m.id !== momentId);
    this.feedback = {
      type: 'confirmation',
      title: 'Confirmation: Moment deleted',
      detail: 'The trip moment was deleted from the timeline.'
    };
    this.saveState();
  }

  getSelectedTrip(): Trip | null {
    if (!this.selectedTripId) return null;
    return this.trips.find(t => t.id === this.selectedTripId) || null;
  }
}

// Global Store Instance
const store = new TripStore();

// View Rendering Engine (Pure HTML/DOM manipulation, zero framework)
function renderApp() {
  const root = document.getElementById('root');
  if (!root) return;

  const currentTrip = store.getSelectedTrip();
  const isCreatorOfSelected = currentTrip ? currentTrip.creatorId === store.currentUser.id : false;
  const isMemberOfSelected = currentTrip ? currentTrip.members.some(m => m.userId === store.currentUser.id) : false;

  let feedbackHtml = '';
  if (store.feedback) {
    const bannerClass = store.feedback.type === 'error' ? 'banner-error' : 'banner-success';
    feedbackHtml = `
      <div class="banner ${bannerClass}" role="alert">
        <div class="banner-title">${escapeHtml(store.feedback.title)}</div>
        <div>${escapeHtml(store.feedback.detail)}</div>
      </div>
    `;
  }

  let contentHtml = '';

  // Tab Content Switching
  if (store.activeTab === 'create-trip') {
    contentHtml = renderCreateTripForm();
  } else if (store.activeTab === 'join-trip') {
    contentHtml = renderJoinTripForm();
  } else if (store.activeTab === 'my-trips') {
    contentHtml = renderMyTripsList();
  } else {
    // Default: 'trip-detail'
    if (store.refusalState.isRefused) {
      // F2-2: Refusal state showing zero trip details
      contentHtml = renderRefusedScreen();
    } else if (currentTrip) {
      contentHtml = renderTripDetail(currentTrip, isCreatorOfSelected, isMemberOfSelected);
    } else {
      contentHtml = renderNoTripsScreen();
    }
  }

  root.innerHTML = `
    <div class="app-container">
      <!-- App Header & Identity -->
      <header class="app-header">
        <div class="brand-row">
          <div>
            <h1 class="app-title">Trip Moments</h1>
            <p class="app-subtitle">Direct, casual moment sharing for trips with friends</p>
          </div>
          <div class="button-row">
            <button id="btn-quick-create" class="btn btn-primary" type="button">Create a trip</button>
            <button id="btn-quick-join" class="btn btn-secondary" type="button">Join a trip</button>
          </div>
        </div>

        <!-- Signed-in Person Identity Bar -->
        <div class="identity-card">
          <div class="identity-header">
            <div>
              <span class="identity-label">Signed-in Person:</span>
              <strong>${escapeHtml(store.currentUser.name)}</strong>
              <span>(${escapeHtml(store.currentUser.email)})</span>
            </div>
            <span class="identity-meta">${escapeHtml(store.currentUser.badge)}</span>
          </div>
          <div class="identity-controls">
            <label for="select-user" class="form-label" style="margin-bottom: 0;">Switch Signed-in Person:</label>
            <select id="select-user" class="input-field" style="width: auto; min-width: 200px;">
              ${PRESET_USERS.map(u => `
                <option value="${u.id}" ${u.id === store.currentUser.id ? 'selected' : ''}>
                  ${escapeHtml(u.name)} (${escapeHtml(u.badge)})
                </option>
              `).join('')}
            </select>
          </div>
        </div>
      </header>

      <!-- Interactive Verification Panel for Features F2-1, F2-2, F2-3 -->
      <section class="verification-strip" aria-labelledby="verification-heading">
        <h2 id="verification-heading" class="verification-title">Feature Verification Controls (F2 Requirements)</h2>
        <p class="verification-desc">Test each requirement directly with pre-configured one-tap test scenarios.</p>
        <div class="test-scenarios-grid">
          <button id="test-f2-1" class="btn btn-secondary" type="button">
            Test F2-1: Create trip with name (make creator & give invite link)
          </button>
          <button id="test-f2-2" class="btn btn-secondary" type="button">
            Test F2-2: Attempt join with invalid link (Refuse & show 0 details)
          </button>
          <button id="test-f2-3-elena" class="btn btn-secondary" type="button">
            Test F2-3: Elena joins using reusable invite link
          </button>
          <button id="test-f2-3-samira" class="btn btn-secondary" type="button">
            Test F2-3: Samira joins using same reusable invite link
          </button>
        </div>
        <div style="margin-top: var(--space-8); text-align: right;">
          <button id="btn-reset-demo" class="btn btn-secondary" type="button" style="font-size: 14px;">
            Reset application to initial state
          </button>
        </div>
      </section>

      <!-- Navigation Tabs -->
      <nav class="tab-row" aria-label="Trip navigation">
        <button id="tab-trip-detail" class="tab-btn ${store.activeTab === 'trip-detail' ? 'active' : ''}" type="button">
          ${currentTrip ? escapeHtml(currentTrip.name) : 'Trip Space'}
        </button>
        <button id="tab-my-trips" class="tab-btn ${store.activeTab === 'my-trips' ? 'active' : ''}" type="button">
          All Trips (${store.trips.length})
        </button>
        <button id="tab-create-trip" class="tab-btn ${store.activeTab === 'create-trip' ? 'active' : ''}" type="button">
          Create New Trip
        </button>
        <button id="tab-join-trip" class="tab-btn ${store.activeTab === 'join-trip' ? 'active' : ''}" type="button">
          Join with Invite Link
        </button>
      </nav>

      <!-- Feedback Area -->
      ${feedbackHtml}

      <!-- Main Body -->
      <main id="main-content">
        ${contentHtml}
      </main>
    </div>
  `;

  attachEventListeners();
}

function renderTripDetail(trip: Trip, isCreator: boolean, isMember: boolean): string {
  const inviteUrl = store.getInviteUrl(trip);

  const membersListHtml = trip.members.map(member => {
    const isCurrentMemberItem = member.userId === store.currentUser.id;
    let actionButton = '';

    // Refusal 2: No icon-only destructive buttons. Button explicitly states what it does.
    if (isCreator && member.role !== 'creator') {
      actionButton = `
        <button class="btn btn-destructive btn-remove-member" data-member-id="${member.userId}" data-member-name="${escapeHtml(member.name)}" type="button">
          Remove ${escapeHtml(member.name)} from trip
        </button>
      `;
    } else if (isCurrentMemberItem && member.role !== 'creator') {
      actionButton = `
        <button class="btn btn-destructive btn-leave-trip" data-trip-id="${trip.id}" type="button">
          Leave ${escapeHtml(trip.name)} trip
        </button>
      `;
    }

    return `
      <li class="member-item">
        <div class="member-info">
          <span class="member-name">${escapeHtml(member.name)} ${isCurrentMemberItem ? '(You)' : ''}</span>
          <span class="member-role">${member.role === 'creator' ? 'Trip Creator' : 'Trip Member'} · ${escapeHtml(member.email)}</span>
        </div>
        ${actionButton}
      </li>
    `;
  }).join('');

  const momentsListHtml = trip.moments.length > 0 ? trip.moments.map(m => `
    <article class="moment-card">
      <div class="moment-meta">
        <span class="moment-author">${escapeHtml(m.authorName)}</span>
        <span>${escapeHtml(m.timestamp)}</span>
      </div>
      <p class="moment-text">${escapeHtml(m.text)}</p>
      <p class="moment-place">Place: <strong>${escapeHtml(m.place)}</strong></p>
      <div style="margin-top: var(--space-8); text-align: right;">
        <button class="btn btn-destructive btn-delete-moment" data-moment-id="${m.id}" type="button">
          Delete trip moment
        </button>
      </div>
    </article>
  `).join('') : `
    <p class="form-help">No moments shared yet. Use the quick share form below to text a photo or story to this trip.</p>
  `;

  return `
    <!-- Trip Summary Header -->
    <section class="card trip-summary-header">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: var(--space-8);">
        <div>
          <h2 class="card-title" style="margin-bottom: var(--space-8);">${escapeHtml(trip.name)}</h2>
          <div class="trip-meta-row">
            <span class="meta-item">Creator: <strong class="meta-creator" style="margin-left: var(--space-8);">${escapeHtml(trip.creatorName)}</strong></span>
            <span class="meta-item">Note: ${escapeHtml(trip.destinationNote)}</span>
            <span class="meta-item">${trip.members.length} Member${trip.members.length === 1 ? '' : 's'}</span>
          </div>
        </div>
        ${isCreator ? `
          <button id="btn-delete-entire-trip" class="btn btn-destructive" type="button">
            Delete trip permanently
          </button>
        ` : ''}
      </div>

      <!-- F2-1 & F2-3: Reusable Invite Link Section -->
      <div class="invite-link-box">
        <h3 style="margin: 0 0 var(--space-8) 0; font-size: var(--font-size-subheading); color: var(--color-primary);">
          Trip Invite Link (Reusable for all members)
        </h3>
        <p style="margin: 0 0 var(--space-8) 0; font-size: var(--font-size-base); color: var(--color-muted);">
          F2-3 Requirement: This single reusable link can be sent to friends on the trip or at home via SMS or text threads. Anyone with this link can join.
        </p>
        <div class="invite-link-row">
          <input id="input-invite-url" class="input-field invite-link-input" type="text" readonly value="${escapeHtml(inviteUrl)}" aria-label="Reusable invite link" />
          <button id="btn-copy-invite-link" class="btn btn-primary" type="button">
            Copy reusable invite link
          </button>
        </div>

        <!-- Text Thread Simulation for Profile 1 Context -->
        <div class="thread-preview-box">
          <div class="thread-preview-title">Profile 1 Context: Casual Text Message Preview</div>
          <div style="font-size: var(--font-size-base); color: var(--color-muted);">
            Marcus sends this directly to his travel buddies instead of posting on social media:
          </div>
          <div class="thread-preview-bubble">
            "Hey! Created our ${escapeHtml(trip.name)} trip space. Tap this link to see photos and spots as they happen today: ${escapeHtml(inviteUrl)}"
          </div>
        </div>
      </div>
    </section>

    <!-- Members Section -->
    <section class="card" aria-labelledby="members-heading">
      <h3 id="members-heading" class="card-title">Trip Members (${trip.members.length})</h3>
      <p class="card-description">
        ${isCreator ? 'You are the creator of this trip. You can invite friends using the reusable link above or manage members.' : 'You are participating as an invited member.'}
      </p>
      <ul class="members-list">
        ${membersListHtml}
      </ul>
    </section>

    <!-- Profile 1 Fast Moment Share Section -->
    ${isMember ? `
      <section class="card" aria-labelledby="share-moment-heading">
        <h3 id="share-moment-heading" class="card-title">Share a Trip Moment (Casual & In-the-Moment)</h3>
        <p class="card-description">
          When something funny, memorable, or a great place happens, share it here so all your friends see it together.
        </p>
        <form id="form-add-moment">
          <div class="form-group">
            <label for="moment-text-input" class="form-label">What just happened? (Quick story or funny moment)</label>
            <textarea id="moment-text-input" class="textarea-field" required placeholder="E.g., Stumbled into a rooftop garden with panoramic views of the river..."></textarea>
          </div>
          <div class="form-group">
            <label for="moment-place-input" class="form-label">Place or neighborhood</label>
            <input id="moment-place-input" class="input-field" type="text" placeholder="E.g., Miradouro de Santa Catarina" />
          </div>
          <button class="btn btn-primary" type="submit">
            Share moment to trip
          </button>
        </form>
      </section>
    ` : `
      <section class="card">
        <p class="form-help">You are not a member of this trip yet. Join with the reusable invite link to post moments.</p>
      </section>
    `}

    <!-- Shared Moments Timeline -->
    <section class="card" aria-labelledby="moments-timeline-heading">
      <h3 id="moments-timeline-heading" class="card-title">Trip Moments Timeline</h3>
      <p class="card-description">All moments kept in one place instead of scattered across multiple text threads.</p>
      <div class="moments-list">
        ${momentsListHtml}
      </div>
    </section>
  `;
}

// F2-1 Screen: Create Trip Form
function renderCreateTripForm(): string {
  return `
    <section class="card" aria-labelledby="create-trip-heading">
      <h2 id="create-trip-heading" class="card-title">Create a New Trip (F2-1 Requirement)</h2>
      <p class="card-description">
        WHEN a signed-in person creates a trip with a name, the app shall make them its creator and give them an invite link.
      </p>
      <div class="banner banner-success" style="margin-bottom: var(--space-16);">
        <div class="banner-title">Creator Assignment Note:</div>
        <div>
          Currently signed in as: <strong>${escapeHtml(store.currentUser.name)}</strong> (${escapeHtml(store.currentUser.email)}).
          Creating this trip will automatically establish you as the creator and generate a reusable invite link.
        </div>
      </div>
      <form id="form-create-trip">
        <div class="form-group">
          <label for="create-trip-name" class="form-label">Trip Name (Required)</label>
          <input id="create-trip-name" class="input-field" type="text" required placeholder="E.g., Kyoto Alleyways & Ramen Run" />
          <span class="form-help">Pick a memorable name for your casual journey.</span>
        </div>
        <div class="form-group">
          <label for="create-trip-destination" class="form-label">Destination or casual dates (Optional)</label>
          <input id="create-trip-destination" class="input-field" type="text" placeholder="E.g., 5-day food and photo wander" />
        </div>
        <div class="button-row">
          <button class="btn btn-primary" type="submit">
            Create trip & generate invite link
          </button>
          <button id="btn-cancel-create" class="btn btn-secondary" type="button">
            Cancel
          </button>
        </div>
      </form>
    </section>
  `;
}

// F2-2 Screen: Join Trip Form
function renderJoinTripForm(): string {
  return `
    <section class="card" aria-labelledby="join-trip-heading">
      <h2 id="join-trip-heading" class="card-title">Join a Trip with Invite Link (F2-2 & F2-3)</h2>
      <p class="card-description">
        Enter a reusable trip invite link or token. If the invite link is invalid, the app will refuse access and show no trip details.
      </p>
      <form id="form-join-trip">
        <div class="form-group">
          <label for="join-invite-token" class="form-label">Paste Trip Invite Link or Token</label>
          <input id="join-invite-token" class="input-field" type="text" required placeholder="E.g., lisbon-casual-moments-token or full URL" />
          <span class="form-help">Enter the reusable invite link texted to you by the trip creator.</span>
        </div>
        <div class="button-row">
          <button class="btn btn-primary" type="submit">
            Join trip
          </button>
          <button id="btn-try-invalid-sample" class="btn btn-destructive" type="button">
            Test invalid link: "bad-fake-token-999"
          </button>
        </div>
      </form>
    </section>
  `;
}

// F2-2 Refused Screen: ZERO trip details shown
function renderRefusedScreen(): string {
  return `
    <section class="card empty-state" aria-labelledby="refusal-heading" style="border: 1px solid var(--color-error);">
      <h2 id="refusal-heading" class="empty-state-title" style="color: var(--color-error);">
        Access Refused: Invalid Invite Link
      </h2>
      <p class="empty-state-text" style="color: var(--color-error); font-weight: 700;">
        F2-2 Enforcement: Someone tried to join a trip without a valid invite link.
      </p>
      <div class="banner banner-error" style="text-align: left; margin: var(--space-16) 0;">
        <div class="banner-title">Refusal Notice:</div>
        <div>
          The invite link <strong>"${escapeHtml(store.refusalState.attemptedLink)}"</strong> does not match any existing trip.
          The app has strictly refused your join request. <strong>Zero trip details (no name, dates, creator, members, or moments) are shown.</strong>
        </div>
      </div>
      <div class="button-row" style="justify-content: center;">
        <button id="btn-dismiss-refusal" class="btn btn-primary" type="button">
          Return to safe trip view
        </button>
        <button id="btn-refusal-try-valid" class="btn btn-secondary" type="button">
          Join with a valid invite link
        </button>
      </div>
    </section>
  `;
}

function renderMyTripsList(): string {
  if (store.trips.length === 0) {
    return renderNoTripsScreen();
  }

  const tripsHtml = store.trips.map(trip => {
    const isSelected = trip.id === store.selectedTripId;
    const isCreator = trip.creatorId === store.currentUser.id;
    const isMember = trip.members.some(m => m.userId === store.currentUser.id);
    const roleText = isCreator ? 'Creator' : isMember ? 'Member' : 'Not a member';

    return `
      <article class="card" style="${isSelected ? 'border-color: var(--color-primary); background-color: #FFFFFF;' : ''}">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: var(--space-8);">
          <div>
            <h3 class="card-title">${escapeHtml(trip.name)}</h3>
            <div class="trip-meta-row">
              <span class="meta-item">Creator: <strong>${escapeHtml(trip.creatorName)}</strong></span>
              <span class="meta-item">Your Role: <strong>${roleText}</strong></span>
              <span class="meta-item">${trip.members.length} Member${trip.members.length === 1 ? '' : 's'}</span>
            </div>
            <p style="margin: var(--space-8) 0 0 0; color: var(--color-muted);">${escapeHtml(trip.destinationNote)}</p>
          </div>
          <div class="button-row">
            <button class="btn btn-primary btn-select-trip" data-trip-id="${trip.id}" type="button">
              View trip details
            </button>
          </div>
        </div>
      </article>
    `;
  }).join('');

  return `
    <section aria-labelledby="all-trips-heading">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-16); flex-wrap: wrap; gap: var(--space-8);">
        <h2 id="all-trips-heading" style="font-size: var(--font-size-heading); color: var(--color-primary); margin: 0;">
          All Available Trips (${store.trips.length})
        </h2>
        <button id="btn-trips-create-new" class="btn btn-primary" type="button">
          Create another trip
        </button>
      </div>
      ${tripsHtml}
    </section>
  `;
}

function renderNoTripsScreen(): string {
  return `
    <section class="card empty-state" aria-labelledby="no-trips-heading">
      <h2 id="no-trips-heading" class="empty-state-title">No Trips Created Yet</h2>
      <p class="empty-state-text">Create your first casual trip to become its creator and receive a reusable invite link for friends.</p>
      <button id="btn-empty-create" class="btn btn-primary" type="button">
        Create a trip now
      </button>
    </section>
  `;
}

// Event Listeners Wiring
function attachEventListeners() {
  // User switcher
  const userSelect = document.getElementById('select-user') as HTMLSelectElement | null;
  if (userSelect) {
    userSelect.addEventListener('change', () => {
      const selected = PRESET_USERS.find(u => u.id === userSelect.value);
      if (selected) {
        store.currentUser = selected;
        store.feedback = {
          type: 'confirmation',
          title: 'Confirmation: Switched signed-in identity',
          detail: `Active identity is now ${selected.name} (${selected.badge}).`
        };
        store.saveState();
        renderApp();
      }
    });
  }

  // Quick navigation buttons in header
  const btnQuickCreate = document.getElementById('btn-quick-create');
  if (btnQuickCreate) {
    btnQuickCreate.addEventListener('click', () => {
      store.refusalState = { isRefused: false, attemptedLink: '' };
      store.activeTab = 'create-trip';
      renderApp();
    });
  }

  const btnQuickJoin = document.getElementById('btn-quick-join');
  if (btnQuickJoin) {
    btnQuickJoin.addEventListener('click', () => {
      store.activeTab = 'join-trip';
      renderApp();
    });
  }

  // Tabs
  const tabTripDetail = document.getElementById('tab-trip-detail');
  if (tabTripDetail) {
    tabTripDetail.addEventListener('click', () => {
      store.activeTab = 'trip-detail';
      renderApp();
    });
  }

  const tabMyTrips = document.getElementById('tab-my-trips');
  if (tabMyTrips) {
    tabMyTrips.addEventListener('click', () => {
      store.refusalState = { isRefused: false, attemptedLink: '' };
      store.activeTab = 'my-trips';
      renderApp();
    });
  }

  const tabCreateTrip = document.getElementById('tab-create-trip');
  if (tabCreateTrip) {
    tabCreateTrip.addEventListener('click', () => {
      store.refusalState = { isRefused: false, attemptedLink: '' };
      store.activeTab = 'create-trip';
      renderApp();
    });
  }

  const tabJoinTrip = document.getElementById('tab-join-trip');
  if (tabJoinTrip) {
    tabJoinTrip.addEventListener('click', () => {
      store.activeTab = 'join-trip';
      renderApp();
    });
  }

  // Verification Scenario Buttons
  // F2-1: Create a trip with a name -> creator + invite link
  const btnTestF21 = document.getElementById('test-f2-1');
  if (btnTestF21) {
    btnTestF21.addEventListener('click', () => {
      store.currentUser = PRESET_USERS[0]; // Marcus Vance
      const trip = store.createTrip('Kyoto Alleyways & Ramen Run', '5-day casual culinary wander with friends');
      store.feedback = {
        type: 'success',
        title: 'Success: F2-1 Verified (Trip created & creator assigned)',
        detail: `Signed-in user ${store.currentUser.name} created "${trip.name}", was assigned as its creator, and was given a reusable invite link.`
      };
      renderApp();
    });
  }

  // F2-2: Attempt join with invalid link -> Refusal with 0 trip details shown
  const btnTestF22 = document.getElementById('test-f2-2');
  if (btnTestF22) {
    btnTestF22.addEventListener('click', () => {
      store.currentUser = PRESET_USERS[3]; // Uninvited Visitor
      store.joinTripWithToken('invalid-fake-token-404');
      renderApp();
    });
  }

  // F2-3: Elena joins using reusable invite link
  const btnTestF23Elena = document.getElementById('test-f2-3-elena');
  if (btnTestF23Elena) {
    btnTestF23Elena.addEventListener('click', () => {
      const lisbonTrip = store.trips.find(t => t.id === 'trip-lisbon-2026') || store.trips[0];
      if (!lisbonTrip) return;
      store.currentUser = PRESET_USERS[1]; // Elena Rostova
      store.joinTripWithToken(lisbonTrip.inviteToken);
      store.feedback = {
        type: 'success',
        title: 'Success: F2-3 Verified (Member joined using reusable invite link)',
        detail: `Elena Rostova successfully joined "${lisbonTrip.name}" using the trip's single reusable invite link.`
      };
      renderApp();
    });
  }

  // F2-3: Samira joins using SAME reusable invite link
  const btnTestF23Samira = document.getElementById('test-f2-3-samira');
  if (btnTestF23Samira) {
    btnTestF23Samira.addEventListener('click', () => {
      const lisbonTrip = store.trips.find(t => t.id === 'trip-lisbon-2026') || store.trips[0];
      if (!lisbonTrip) return;
      store.currentUser = PRESET_USERS[2]; // Samira Chen
      store.joinTripWithToken(lisbonTrip.inviteToken);
      store.feedback = {
        type: 'success',
        title: 'Success: F2-3 Verified (Second member joined using SAME reusable invite link)',
        detail: `Samira Chen successfully joined "${lisbonTrip.name}" using the exact same reusable link. The link remains valid and reusable.`
      };
      renderApp();
    });
  }

  // Reset Demo State button
  const btnResetDemo = document.getElementById('btn-reset-demo');
  if (btnResetDemo) {
    btnResetDemo.addEventListener('click', () => {
      store.resetAll();
      renderApp();
    });
  }

  // Copy Invite Link button
  const btnCopyInvite = document.getElementById('btn-copy-invite-link');
  if (btnCopyInvite) {
    btnCopyInvite.addEventListener('click', () => {
      const input = document.getElementById('input-invite-url') as HTMLInputElement | null;
      if (input) {
        input.select();
        navigator.clipboard.writeText(input.value).then(() => {
          store.feedback = {
            type: 'success',
            title: 'Success: Reusable invite link copied',
            detail: 'The single reusable invite link has been copied to your clipboard. Ready to paste into SMS or group text threads.'
          };
          renderApp();
        }).catch(() => {
          store.feedback = {
            type: 'confirmation',
            title: 'Confirmation: Link highlighted',
            detail: 'Link selected in input. Press Ctrl+C or Cmd+C to copy.'
          };
          renderApp();
        });
      }
    });
  }

  // Form: Create Trip (F2-1)
  const formCreateTrip = document.getElementById('form-create-trip');
  if (formCreateTrip) {
    formCreateTrip.addEventListener('submit', (e) => {
      e.preventDefault();
      const nameInput = document.getElementById('create-trip-name') as HTMLInputElement | null;
      const destInput = document.getElementById('create-trip-destination') as HTMLInputElement | null;
      if (!nameInput || !nameInput.value.trim()) return;

      const newTrip = store.createTrip(nameInput.value, destInput ? destInput.value : '');
      store.feedback = {
        type: 'success',
        title: 'Success: Trip created (F2-1)',
        detail: `Trip "${newTrip.name}" was created. ${store.currentUser.name} is set as its creator. Your reusable invite link is ready.`
      };
      renderApp();
    });
  }

  const btnCancelCreate = document.getElementById('btn-cancel-create');
  if (btnCancelCreate) {
    btnCancelCreate.addEventListener('click', () => {
      store.activeTab = store.trips.length > 0 ? 'trip-detail' : 'my-trips';
      renderApp();
    });
  }

  // Form: Join Trip (F2-2 & F2-3)
  const formJoinTrip = document.getElementById('form-join-trip');
  if (formJoinTrip) {
    formJoinTrip.addEventListener('submit', (e) => {
      e.preventDefault();
      const tokenInput = document.getElementById('join-invite-token') as HTMLInputElement | null;
      if (!tokenInput) return;
      store.joinTripWithToken(tokenInput.value);
      renderApp();
    });
  }

  const btnTryInvalidSample = document.getElementById('btn-try-invalid-sample');
  if (btnTryInvalidSample) {
    btnTryInvalidSample.addEventListener('click', () => {
      store.joinTripWithToken('bad-fake-token-999');
      renderApp();
    });
  }

  // Refusal screen buttons
  const btnDismissRefusal = document.getElementById('btn-dismiss-refusal');
  if (btnDismissRefusal) {
    btnDismissRefusal.addEventListener('click', () => {
      store.refusalState = { isRefused: false, attemptedLink: '' };
      store.activeTab = store.trips.length > 0 ? 'trip-detail' : 'my-trips';
      store.feedback = null;
      renderApp();
    });
  }

  const btnRefusalTryValid = document.getElementById('btn-refusal-try-valid');
  if (btnRefusalTryValid) {
    btnRefusalTryValid.addEventListener('click', () => {
      store.refusalState = { isRefused: false, attemptedLink: '' };
      store.activeTab = 'join-trip';
      renderApp();
    });
  }

  // Trip selection buttons
  const selectTripButtons = document.querySelectorAll('.btn-select-trip');
  selectTripButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const tripId = btn.getAttribute('data-trip-id');
      if (tripId) {
        store.selectedTripId = tripId;
        store.activeTab = 'trip-detail';
        store.refusalState = { isRefused: false, attemptedLink: '' };
        renderApp();
      }
    });
  });

  const btnTripsCreateNew = document.getElementById('btn-trips-create-new');
  if (btnTripsCreateNew) {
    btnTripsCreateNew.addEventListener('click', () => {
      store.activeTab = 'create-trip';
      renderApp();
    });
  }

  const btnEmptyCreate = document.getElementById('btn-empty-create');
  if (btnEmptyCreate) {
    btnEmptyCreate.addEventListener('click', () => {
      store.activeTab = 'create-trip';
      renderApp();
    });
  }

  // Delete entire trip button (Refusal 2: explicit text button)
  const btnDeleteEntireTrip = document.getElementById('btn-delete-entire-trip');
  if (btnDeleteEntireTrip) {
    btnDeleteEntireTrip.addEventListener('click', () => {
      const trip = store.getSelectedTrip();
      if (trip) {
        store.deleteTrip(trip.id);
        renderApp();
      }
    });
  }

  // Remove member buttons (Refusal 2: explicit text button)
  const removeMemberButtons = document.querySelectorAll('.btn-remove-member');
  removeMemberButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const trip = store.getSelectedTrip();
      const memberId = btn.getAttribute('data-member-id');
      if (trip && memberId) {
        store.removeMember(trip.id, memberId);
        renderApp();
      }
    });
  });

  // Leave trip button
  const leaveTripButtons = document.querySelectorAll('.btn-leave-trip');
  leaveTripButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const trip = store.getSelectedTrip();
      if (trip) {
        store.removeMember(trip.id, store.currentUser.id);
        renderApp();
      }
    });
  });

  // Form: Add Moment (Profile 1 fast share)
  const formAddMoment = document.getElementById('form-add-moment');
  if (formAddMoment) {
    formAddMoment.addEventListener('submit', (e) => {
      e.preventDefault();
      const trip = store.getSelectedTrip();
      const textInput = document.getElementById('moment-text-input') as HTMLTextAreaElement | null;
      const placeInput = document.getElementById('moment-place-input') as HTMLInputElement | null;
      if (!trip || !textInput || !textInput.value.trim()) return;

      store.addMoment(trip.id, textInput.value, placeInput ? placeInput.value : '');
      renderApp();
    });
  }

  // Delete moment buttons (Refusal 2: explicit text button)
  const deleteMomentButtons = document.querySelectorAll('.btn-delete-moment');
  deleteMomentButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const trip = store.getSelectedTrip();
      const momentId = btn.getAttribute('data-moment-id');
      if (trip && momentId) {
        store.deleteMoment(trip.id, momentId);
        renderApp();
      }
    });
  });
}

// Utility: HTML escaping to prevent XSS
function escapeHtml(str: string): string {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Automatic URL invite parameter detection on initial load
function checkUrlInviteParam() {
  const urlParams = new URLSearchParams(window.location.search);
  const inviteParam = urlParams.get('invite');
  if (inviteParam) {
    store.joinTripWithToken(inviteParam);
  }
}

// Initial bootstrap
window.addEventListener('DOMContentLoaded', () => {
  checkUrlInviteParam();
  renderApp();
});

// Also trigger immediately in case DOM is already parsed
if (document.readyState === 'interactive' || document.readyState === 'complete') {
  checkUrlInviteParam();
  renderApp();
}
