import { supabase } from '../supabase-client.js'

/**
 * Render the trips dashboard: a list of the signed-in user's trips plus a form
 * to create a new trip. On create, onCreate(trip) is called with the new trip.
 */
export async function renderDashboard(container, { onOpenTrip, onCreate }) {
  container.innerHTML = `<div class="loading">Loading your trips…</div>`

  const { data: trips, error } = await supabase
    .from('trips')
    .select('id, name, created_at, creator_id')
    .order('created_at', { ascending: false })

  const root = document.createElement('div')
  root.className = 'container'

  if (error) {
    root.innerHTML = `
      <div class="alert alert-error" role="alert">
        We could not load your trips. Please try again.
      </div>
    `
    container.innerHTML = ''
    container.appendChild(root)
    return
  }

  root.innerHTML = `
    <div class="section-head">
      <h1>Your trips</h1>
    </div>

    <div class="card mb-16">
      <h2 class="mb-16">Start a new trip</h2>
      <form id="create-trip-form" novalidate>
        <div class="form-group">
          <label for="trip-name">Trip name</label>
          <input type="text" id="trip-name" required maxlength="80" placeholder="e.g. Weekend in Lisbon" />
        </div>
        <div id="create-error" class="alert alert-error" role="alert" hidden></div>
        <div id="create-success" class="alert alert-success" role="status" hidden></div>
        <button type="submit" class="btn btn-primary" id="create-submit">Create trip</button>
      </form>
    </div>

    <div id="trip-list-wrap"></div>
  `
  container.innerHTML = ''
  container.appendChild(root)

  renderTripList(root.querySelector('#trip-list-wrap'), trips, onOpenTrip)

  const form = root.querySelector('#create-trip-form')
  const errBox = root.querySelector('#create-error')
  const okBox = root.querySelector('#create-success')
  const submitBtn = root.querySelector('#create-submit')

  form.addEventListener('submit', async (e) => {
    e.preventDefault()
    errBox.hidden = true
    okBox.hidden = true

    const name = root.querySelector('#trip-name').value.trim()
    if (!name) {
      errBox.textContent = 'Please enter a trip name.'
      errBox.hidden = false
      return
    }

    submitBtn.disabled = true
    submitBtn.textContent = 'Creating…'

    try {
      const { data, error: rpcError } = await supabase.rpc('create_trip', { p_name: name })
      if (rpcError) throw rpcError
      if (!data) throw new Error('Could not create the trip.')

      okBox.textContent = `"${data.name}" is ready. Share its invite link to add people.`
      okBox.hidden = false
      root.querySelector('#trip-name').value = ''

      // Prepend the new trip to the list.
      const list = root.querySelector('#trip-list-wrap')
      trips.unshift(data)
      renderTripList(list, trips, onOpenTrip)

      onCreate(data)
    } catch (err) {
      errBox.textContent = err.message || 'Could not create the trip. Please try again.'
      errBox.hidden = false
    } finally {
      submitBtn.disabled = false
      submitBtn.textContent = 'Create trip'
    }
  })
}

function renderTripList(wrap, trips, onOpenTrip) {
  if (!trips || trips.length === 0) {
    wrap.innerHTML = `
      <div class="card empty-state">
        <h2>No trips yet</h2>
        <p>Create your first trip above, then share its invite link with friends.</p>
      </div>
    `
    return
  }

  const ul = document.createElement('ul')
  ul.className = 'trip-list'
  trips.forEach((trip) => {
    const li = document.createElement('li')
    li.className = 'trip-item'
    li.innerHTML = `
      <div>
        <div class="trip-name">${escapeHtml(trip.name)}</div>
        <div class="trip-meta">Created ${formatDate(trip.created_at)}</div>
      </div>
      <button type="button" class="btn btn-secondary open-btn">Open trip</button>
    `
    li.querySelector('.open-btn').addEventListener('click', () => onOpenTrip(trip))
    ul.appendChild(li)
  })
  wrap.innerHTML = ''
  wrap.appendChild(ul)
}

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })
  } catch {
    return ''
  }
}

function escapeHtml(s) {
  const div = document.createElement('div')
  div.textContent = s
  return div.innerHTML
}
