import { supabase } from '../supabase-client.js'

/**
 * Render the auth screen (sign in / sign up) into the given container element.
 * On successful auth, onAuthed() is called so the app can switch views.
 */
export function renderAuth(container, onAuthed) {
  let mode = 'signin'

  const shell = document.createElement('div')
  shell.className = 'auth-wrap'
  shell.innerHTML = `
    <div class="card auth-card">
      <h1 class="mb-16">Welcome</h1>
      <div class="auth-tabs" role="tablist">
        <button type="button" class="auth-tab active" data-mode="signin" role="tab">Sign in</button>
        <button type="button" class="auth-tab" data-mode="signup" role="tab">Create account</button>
      </div>
      <form id="auth-form" novalidate>
        <div class="form-group" id="name-group" hidden>
          <label for="auth-name">Display name</label>
          <input type="text" id="auth-name" autocomplete="name" placeholder="Your name" />
        </div>
        <div class="form-group">
          <label for="auth-email">Email</label>
          <input type="email" id="auth-email" autocomplete="email" required placeholder="you@example.com" />
        </div>
        <div class="form-group">
          <label for="auth-password">Password</label>
          <input type="password" id="auth-password" autocomplete="current-password" required minlength="6" placeholder="At least 6 characters" />
        </div>
        <div id="auth-error" class="alert alert-error" role="alert" hidden></div>
        <button type="submit" class="btn btn-primary btn-block" id="auth-submit">Sign in</button>
      </form>
    </div>
  `
  container.innerHTML = ''
  container.appendChild(shell)

  const tabs = shell.querySelectorAll('.auth-tab')
  const nameGroup = shell.querySelector('#name-group')
  const submitBtn = shell.querySelector('#auth-submit')
  const errorBox = shell.querySelector('#auth-error')
  const form = shell.querySelector('#auth-form')

  function setMode(next) {
    mode = next
    tabs.forEach((t) => t.classList.toggle('active', t.dataset.mode === next))
    const isSignup = next === 'signup'
    nameGroup.hidden = !isSignup
    submitBtn.textContent = isSignup ? 'Create account' : 'Sign in'
    errorBox.hidden = true
  }

  tabs.forEach((t) => t.addEventListener('click', () => setMode(t.dataset.mode)))

  function showError(msg) {
    errorBox.textContent = msg
    errorBox.hidden = false
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault()
    errorBox.hidden = true
    const email = shell.querySelector('#auth-email').value.trim()
    const password = shell.querySelector('#auth-password').value

    if (!email || !password) {
      showError('Please enter your email and password.')
      return
    }
    if (password.length < 6) {
      showError('Password must be at least 6 characters.')
      return
    }

    submitBtn.disabled = true
    submitBtn.textContent = mode === 'signup' ? 'Creating…' : 'Signing in…'

    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({ email, password })
        if (error) throw error
        if (data.user && !data.session) {
          showError('Account created. Check your email to confirm before signing in.')
          setMode('signin')
          return
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
      }
      onAuthed()
    } catch (err) {
      const msg = err.message || 'Something went wrong. Please try again.'
      showError(friendlyAuthError(msg))
    } finally {
      submitBtn.disabled = false
      submitBtn.textContent = mode === 'signup' ? 'Create account' : 'Sign in'
    }
  })
}

function friendlyAuthError(msg) {
  const m = msg.toLowerCase()
  if (m.includes('invalid login credentials')) return 'Email or password is incorrect.'
  if (m.includes('user already registered')) return 'An account with this email already exists. Try signing in.'
  if (m.includes('rate limit') || m.includes('too many')) return 'Too many attempts. Please wait a moment and try again.'
  return msg
}
