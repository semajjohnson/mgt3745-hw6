import { supabase } from '../supabase-client.js'

/**
 * Render the trip detail view: trip name, the reusable invite link with a copy
 * button, and the member list. Only the creator can remove members.
 */
export async function renderTripDetail(container, { trip, onBack }) {
  container.innerHTML = `<div class="loading">Loading trip…</div>`

  const { data: tripRow, error: tripErr } = await supabase
    .from('trips')
    .select('id, name, invite_code, creator_id, created_at')
    .eq('id', trip.id)
    .maybeSingle()

  if (tripErr || !tripRow) {
    const root = document.createElement('div')
    root.className = 'container'
    root.innerHTML = `
      <button type="button" class="back-link">&larr; Back to trips</button>
      <div class="alert alert-error" role="alert">
        This trip could not be found, or you do not have access to it.
      </div>
    `
    container.innerHTML = ''
    container.appendChild(root)
    root.querySelector('.back-link').addEventListener('click', onBack)
    return
  }

  const { data: members, error: membersErr } = await supabase
    .from('trip_members')
    .select('id, user_id, joined_at')
    .eq('trip_id', tripRow.id)
    .order('joined_at', { ascending: true })

  // Fetch emails for member user ids from auth via the profiles RPC fallback:
  // Supabase does not expose auth.users to the anon client, so we show user_id
  // derived display labels and the creator is flagged. We attempt a join on a
  // profiles table if present; otherwise fall back to a friendly label.
  const profileMap = await loadProfiles((members || []).map((m) => m.user_id))

  const root = document.createElement('div')
  root.className = 'container'

  const inviteUrl = buildInviteUrl(tripRow.invite_code)
  const isCreator = tripRow.creator_id === (await currentUserId())

  root.innerHTML = `
    <button type="button" class="back-link">&larr; Back to trips</button>
    <div class="detail-head">
      <h1 class="trip-title">${escapeHtml(tripRow.name)}</h1>
      <div class="trip-created">Created ${formatDate(tripRow.created_at)}</div>
    </div>

    <div class="card mb-16">
      <h2 class="mb-8">Invite link</h2>
      <p class="text-sm muted mb-8">Share this link with anyone you want on the trip. It is reusable: anyone who opens it and signs in joins the trip.</p>
      <div class="invite-box">
        <label for="invite-link-input">Trip invite link</label>
        <div class="invite-link-row">
          <input id="invite-link-input" class="invite-link" type="text" readonly value="${escapeHtml(inviteUrl)}" />
          <button type="button" class="btn btn-primary" id="copy-invite">Copy link</button>
        </div>
        <div id="copy-result" class="alert alert-success mt-8" role="status" hidden></div>
      </div>
    </div>

    <div class="card">
      <h2 class="mb-16">Members</h2>
      <ul class="members-list" id="members-list"></ul>
      <div id="member-action-error" class="alert alert-error mt-16" role="alert" hidden></div>
    </div>
  `

  container.innerHTML = ''
  container.appendChild(root)
  root.querySelector('.back-link').addEventListener('click', onBack)

  renderMembers(root.querySelector('#members-list'), members || [], tripRow, profileMap, isCreator)

  const copyBtn = root.querySelector('#copy-invite')
  const copyResult = root.querySelector('#copy-result')
  copyBtn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl)
      copyResult.textContent = 'Link copied to clipboard.'
      copyResult.className = 'alert alert-success mt-8'
      copyResult.hidden = false
    } catch {
      // Fallback: select the input so the user can copy manually.
      const input = root.querySelector('#invite-link-input')
      input.select()
      copyResult.textContent = 'Could not copy automatically. The link is selected — press Ctrl+C (or Cmd+C) to copy.'
      copyResult.className = 'alert alert-info mt-8'
      copyResult.hidden = false
    }
  })

  if (membersErr) {
    const errBox = root.querySelector('#member-action-error')
    errBox.textContent = 'Could not load all member details.'
    errBox.hidden = false
  }
}

async function renderMembers(ul, members, trip, profileMap, isCreator) {
  ul.innerHTML = ''
  members.forEach((m) => {
    const isTripCreator = m.user_id === trip.creator_id
    const label = profileMap.get(m.user_id) || friendlyMemberLabel(m.user_id, isTripCreator)
    const li = document.createElement('li')
    li.className = 'member-item'
    li.innerHTML = `
      <div>
        <div class="member-email">${escapeHtml(label)}</div>
        <div class="text-sm muted">Joined ${formatDate(m.joined_at)}</div>
      </div>
      <div style="display:flex;align-items:center;gap:8px;">
        <span class="member-role${isTripCreator ? ' creator' : ''}">${isTripCreator ? 'Creator' : 'Member'}</span>
        ${
          isCreator && !isTripCreator
            ? `<button type="button" class="btn btn-danger" data-member-id="${m.id}">Remove member</button>`
            : ''
        }
      </div>
    `
    const removeBtn = li.querySelector('[data-member-id]')
    if (removeBtn) {
      removeBtn.addEventListener('click', () => removeMember(ul, m, trip))
    }
    ul.appendChild(li)
  })
}

async function removeMember(ul, member, trip) {
  const errBox = ul.closest('.container').querySelector('#member-action-error')
  errBox.hidden = true

  const { error } = await supabase
    .from('trip_members')
    .delete()
    .eq('id', member.id)

  if (error) {
    errBox.textContent = 'Could not remove this member. Please try again.'
    errBox.hidden = false
    return
  }
  // Re-render the detail view by reloading.
  const li = ul.querySelector(`[data-member-id="${member.id}"]`)?.closest('.member-item')
  if (li) li.remove()
}

function buildInviteUrl(code) {
  const base = `${window.location.origin}${window.location.pathname}`
  return `${base}#/join/${code}`
}

function friendlyMemberLabel(userId, isCreator) {
  if (isCreator) return 'You (creator)'
  return `Member ${userId.slice(0, 8)}`
}

async function loadProfiles(userIds) {
  const map = new Map()
  // The anon key cannot read auth.users. If a profiles table is added later,
  // it would be queried here. For now we return an empty map and use friendly
  // labels. The creator's own email is shown via the header elsewhere.
  return map
}

async function currentUserId() {
  const { data } = await supabase.auth.getUser()
  return data?.user?.id || null
}

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })
  } catch {
    return ''
  }
}

function escapeHtml(s) {
  const div = document.createElement('div')
  div.textContent = s
  return div.innerHTML
}
