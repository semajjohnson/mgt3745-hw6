import { supabase } from '../supabase-client.js'

/**
 * Render the join view. It validates the invite code from the URL. If the code
 * is missing or invalid, the app refuses to join and shows no trip details.
 * If valid and the user is signed in, they join the trip. If not signed in,
 * they are asked to sign in first, preserving the invite code.
 */
export async function renderJoin(container, { inviteCode, onJoined, onNeedAuth }) {
  const root = document.createElement('div')
  root.className = 'join-wrap'
  root.innerHTML = `
    <div class="card join-card">
      <h1 class="mb-16">Join a trip</h1>
      <div id="join-status"></div>
    </div>
  `
  container.innerHTML = ''
  container.appendChild(root)

  const status = root.querySelector('#join-status')

  if (!inviteCode) {
    status.innerHTML = `
      <div class="alert alert-error" role="alert">
        This invite link is not valid. Ask the trip creator for a new link.
      </div>
    `
    return
  }

  status.innerHTML = `<div class="loading">Checking your invite link…</div>`

  const { data: session } = await supabase.auth.getSession()
  if (!session.data?.session) {
    status.innerHTML = `
      <div class="alert alert-info" role="status">
        You need to sign in before you can join this trip.
      </div>
      <button type="button" class="btn btn-primary btn-block" id="go-signin">Go to sign in</button>
    `
    root.querySelector('#go-signin').addEventListener('click', () => onNeedAuth(inviteCode))
    return
  }

  const { data: trip, error } = await supabase.rpc('join_trip', { p_invite_code: inviteCode })

  if (error) {
    status.innerHTML = `
      <div class="alert alert-error" role="alert">
        Something went wrong while joining. Please try again.
      </div>
    `
    return
  }

  if (!trip) {
    // F2-2: refuse without a valid invite link, show no trip details.
    status.innerHTML = `
      <div class="alert alert-error" role="alert">
        This invite link is not valid. Ask the trip creator for a new link.
      </div>
    `
    return
  }

  status.innerHTML = `
    <div class="alert alert-success" role="status">
      You joined "${escapeHtml(trip.name)}".
    </div>
    <button type="button" class="btn btn-primary btn-block" id="open-joined-trip">Open trip</button>
  `
  root.querySelector('#open-joined-trip').addEventListener('click', () => onJoined(trip))
}

function escapeHtml(s) {
  const div = document.createElement('div')
  div.textContent = s
  return div.innerHTML
}
