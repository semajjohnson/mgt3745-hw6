/*
# Harden create_trip / join_trip: revoke anon execute

The SECURITY DEFINER functions create_trip and join_trip use auth.uid() internally,
so anonymous callers (auth.uid() = null) cannot create or join trips. To close the
gap flagged by the database advisor, this migration explicitly revokes EXECUTE from
the anon role so anon cannot even call the functions over the REST API. Only
authenticated users retain execute permission.
*/

REVOKE EXECUTE ON FUNCTION create_trip(text) FROM anon;
REVOKE EXECUTE ON FUNCTION join_trip(text) FROM anon;
