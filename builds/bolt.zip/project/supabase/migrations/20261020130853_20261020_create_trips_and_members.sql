/*
# Create trips, trip_members, and join_trip RPC

This migration introduces the data layer for the "Create a trip and invite members"
feature (F2). A signed-in user creates a trip, becomes its creator, and receives one
reusable invite link. Other users can join a trip only with a valid invite link; any
attempt without a valid link is refused and exposes no trip details.

## 1. New tables

- `trips` (created first; trip_members references it)
  - `id`            uuid, primary key (default gen_random_uuid())
  - `name`          text, not null -- the trip's display name
  - `invite_code`   text, not null, unique -- random token used in the reusable invite link
  - `creator_id`    uuid, not null, default auth.uid() -- the signed-in creator, references auth.users
  - `created_at`    timestamptz, default now()

- `trip_members`
  - `id`        uuid, primary key (default gen_random_uuid())
  - `trip_id`   uuid, not null, references trips(id) on delete cascade
  - `user_id`   uuid, not null, references auth.users(id) on delete cascade
  - `joined_at` timestamptz, default now()
  - unique(trip_id, user_id) -- a user is a member of a trip at most once

## 2. Access model

Trips and members are only visible to trip members. The creator is a member at
create time (inserted by the create_trip RPC), so they can see their own trip.
RLS is enabled on both tables.

- trips: SELECT scoped to members of the trip via trip_members; INSERT/UPDATE/DELETE
  scoped to the creator.
- trip_members: SELECT scoped to trips the caller is a member of; INSERT/DELETE only
  by the trip creator (manage membership).

## 3. SECURITY DEFINER RPCs

- `create_trip(p_name text)`: creates the trip + creator membership, returns the trip.
- `join_trip(p_invite_code text)`: validates the invite code, adds the caller as a
  member, returns the trip; returns NULL for an invalid code so no details leak.

## 4. Security notes

- All SELECT/INSERT/UPDATE/DELETE on trips and trip_members go through RLS.
- The two RPCs are SECURITY DEFINER so they can atomically create+join and look up
  by invite_code, then return the row to the caller. auth.uid() is used inside the
  function bodies so anonymous users cannot create or join trips.
- invite_code is a 32-char URL-safe random token, unique per trip.
- No destructive operations on existing data (brand-new schema).
*/

-- ============================================================
-- trips (created first; trip_members references it)
-- ============================================================
CREATE TABLE IF NOT EXISTS trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  invite_code text NOT NULL UNIQUE,
  creator_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE trips ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- trip_members
-- ============================================================
CREATE TABLE IF NOT EXISTS trip_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (trip_id, user_id)
);

ALTER TABLE trip_members ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- trips policies
-- ============================================================
-- A caller can see a trip if they are a member of it.
DROP POLICY IF EXISTS "select_trips_as_member" ON trips;
CREATE POLICY "select_trips_as_member"
ON trips FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM trip_members tm
    WHERE tm.trip_id = trips.id AND tm.user_id = auth.uid()
  )
);

-- Trip creation goes through the create_trip RPC (SECURITY DEFINER).
DROP POLICY IF EXISTS "insert_trips_as_creator" ON trips;
CREATE POLICY "insert_trips_as_creator"
ON trips FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = creator_id);

-- Only the creator can update/delete a trip's metadata.
DROP POLICY IF EXISTS "update_trips_as_creator" ON trips;
CREATE POLICY "update_trips_as_creator"
ON trips FOR UPDATE
TO authenticated
USING (auth.uid() = creator_id)
WITH CHECK (auth.uid() = creator_id);

DROP POLICY IF EXISTS "delete_trips_as_creator" ON trips;
CREATE POLICY "delete_trips_as_creator"
ON trips FOR DELETE
TO authenticated
USING (auth.uid() = creator_id);

-- ============================================================
-- trip_members policies
-- ============================================================
-- A caller can see memberships for trips they are a member of.
DROP POLICY IF EXISTS "select_trip_members_as_member" ON trip_members;
CREATE POLICY "select_trip_members_as_member"
ON trip_members FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM trip_members tm
    WHERE tm.trip_id = trip_members.trip_id AND tm.user_id = auth.uid()
  )
);

-- Only the trip creator can add or remove members directly.
DROP POLICY IF EXISTS "insert_trip_members_as_creator" ON trip_members;
CREATE POLICY "insert_trip_members_as_creator"
ON trip_members FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM trips t
    WHERE t.id = trip_members.trip_id AND t.creator_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "delete_trip_members_as_creator" ON trip_members;
CREATE POLICY "delete_trip_members_as_creator"
ON trip_members FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM trips t
    WHERE t.id = trip_members.trip_id AND t.creator_id = auth.uid()
  )
);

-- ============================================================
-- create_trip(p_name text)
-- ============================================================
CREATE OR REPLACE FUNCTION create_trip(p_name text)
RETURNS trips
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id uuid DEFAULT gen_random_uuid();
  v_code text;
  v_trip trips%ROWTYPE;
BEGIN
  IF p_name IS NULL OR btrim(p_name) = '' THEN
    RAISE EXCEPTION 'Trip name is required';
  END IF;

  -- Generate a 32-char URL-safe random invite code.
  v_code := replace(gen_random_uuid()::text, '-', '') || upper(to_hex(floor(random() * 1000000)::int));
  v_code := substr(v_code, 1, 32);

  INSERT INTO trips (id, name, invite_code, creator_id)
  VALUES (v_id, btrim(p_name), v_code, auth.uid())
  RETURNING * INTO v_trip;

  INSERT INTO trip_members (trip_id, user_id)
  VALUES (v_id, auth.uid());

  RETURN v_trip;
END;
$$;

REVOKE ALL ON FUNCTION create_trip(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION create_trip(text) TO authenticated;

-- ============================================================
-- join_trip(p_invite_code text)
-- ============================================================
-- Returns the trip row on success, or NULL when the invite code is invalid.
-- Never exposes trip details for an invalid code.
CREATE OR REPLACE FUNCTION join_trip(p_invite_code text)
RETURNS trips
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_trip trips%ROWTYPE;
BEGIN
  IF p_invite_code IS NULL OR btrim(p_invite_code) = '' THEN
    RETURN NULL;
  END IF;

  SELECT * INTO v_trip FROM trips WHERE invite_code = btrim(p_invite_code);
  IF NOT FOUND THEN
    RETURN NULL;
  END IF;

  INSERT INTO trip_members (trip_id, user_id)
  VALUES (v_trip.id, auth.uid())
  ON CONFLICT (trip_id, user_id) DO NOTHING;

  RETURN v_trip;
END;
$$;

REVOKE ALL ON FUNCTION join_trip(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION join_trip(text) TO authenticated;
