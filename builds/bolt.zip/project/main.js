import './style.css'
import { supabase } from './supabase-client.js'
import { renderAuth } from './views/auth-view.js'
import { renderDashboard } from './views/dashboard-view.js'
import { renderTripDetail } from './views/trip-detail-view.js'
import { renderJoin } from './views/join-view.js'

const app = document.querySelector('#app')

let currentUser = null
let pendingInviteCode = null

function clearApp() {
  app.innerHTML = ''
}

function renderShell() {
  const shell = document.createElement('div')
  shell.className = 'app-shell'
  shell.innerHTML = `
    <header class="app-header">
      <button type="button" class="brand" id="brand-home">Tripcast</button>
      <div class="header-right" id="header-right"></div>
    </header>
    <main class="app-main" id="app-main"></main>
  `
  app.innerHTML = ''
  app.appendChild(shell)
  shell.querySelector('#brand-home').addEventListener('click', () => navigate('dashboard'))
  return shell.querySelector('#app-main')
}

function renderHeaderRight() {
  const right = app.querySelector('#header-right')
  if (!right) return
  if (currentUser) {
    right.innerHTML = `
      <span class="user-email">${escapeHtml(currentUser.email || '')}</span>
      <button type="button" class="btn btn-secondary" id="signout-btn">Sign out</button>
    `
    right.querySelector('#signout-btn').addEventListener('click', async () => {
      await supabase.auth.signOut()
      // onAuthStateChange will handle the view switch.
    })
  } else {
    right.innerHTML = ''
  }
}

function navigate(view, payload = {}) {
  const hash = buildHash(view, payload)
  if (window.location.hash !== hash) {
    window.location.hash = hash
  } else {
    handleRoute()
  }
}

function buildHash(view, payload) {
  if (view === 'join' && payload.inviteCode) return `#/join/${payload.inviteCode}`
  if (view === 'trip' && payload.tripId) return `#/trip/${payload.tripId}`
  return '#/dashboard'
}

function parseHash() {
  const h = window.location.hash.replace(/^#\/?/, '')
  const parts = h.split('/')
  if (parts[0] === 'join' && parts[1]) {
    return { view: 'join', inviteCode: decodeURIComponent(parts[1]) }
  }
  if (parts[0] === 'trip' && parts[1]) {
    return { view: 'trip', tripId: parts[1] }
  }
  return { view: 'dashboard' }
}

function handleRoute() {
  const route = parseHash()
  const main = renderShell()
  renderHeaderRight()

  if (!currentUser) {
    // Not signed in.
    if (route.view === 'join' && route.inviteCode) {
      pendingInviteCode = route.inviteCode
      renderAuth(main, () => {
        // After auth, the onAuthStateChange handler will re-route and try to join.
      })
      return
    }
    renderAuth(main, () => {})
    return
  }

  // Signed in.
  if (route.view === 'join') {
    renderJoin(main, {
      inviteCode: route.inviteCode,
      onJoined: (trip) => navigate('trip', { tripId: trip.id }),
      onNeedAuth: () => navigate('dashboard'),
    })
    return
  }

  if (route.view === 'trip') {
    renderTripDetail(main, {
      trip: { id: route.tripId },
      onBack: () => navigate('dashboard'),
    })
    return
  }

  renderDashboard(main, {
    onOpenTrip: (trip) => navigate('trip', { tripId: trip.id }),
    onCreate: (trip) => navigate('trip', { tripId: trip.id }),
  })
}

// --- Auth state ---
async function init() {
  const { data } = await supabase.auth.getSession()
  currentUser = data.session?.user || null
  handleRoute()
}

supabase.auth.onAuthStateChange((_event, session) => {
  ;(async () => {
    const prevUser = currentUser
    currentUser = session?.user || null

    if (currentUser && !prevUser && pendingInviteCode) {
      // A user just signed in with a pending invite; route to join.
      const code = pendingInviteCode
      pendingInviteCode = null
      window.location.hash = `#/join/${code}`
      handleRoute()
      return
    }

    if (!currentUser && prevUser) {
      // Signed out: go to a clean state.
      pendingInviteCode = null
      window.location.hash = ''
      handleRoute()
      return
    }

    handleRoute()
  })()
})

window.addEventListener('hashchange', handleRoute)

init()

function escapeHtml(s) {
  const div = document.createElement('div')
  div.textContent = s
  return div.innerHTML
}
